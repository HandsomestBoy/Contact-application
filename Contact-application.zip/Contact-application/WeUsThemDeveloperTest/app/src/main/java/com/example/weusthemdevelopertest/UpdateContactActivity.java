package com.example.weusthemdevelopertest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateContactActivity extends AppCompatActivity {
    private EditText firstNameEdt, lastNameEdt, emailEdt, phoneNumberEdt;
    private Button updateContactBtn, deleteContactBtn;
    private DBHandler dbHandler;
    String firstName, lastName, email, phoneNumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_contact);
        firstNameEdt = findViewById(R.id.idEdtFirstName);
        lastNameEdt = findViewById(R.id.idEdtLastName);
        emailEdt = findViewById(R.id.idEdtEmail);
        phoneNumberEdt = findViewById(R.id.idEdtPhoneNumber);
        updateContactBtn = findViewById(R.id.idBtnUpdateContact);
        deleteContactBtn = findViewById(R.id.idBtnDelete);
        dbHandler = new DBHandler(UpdateContactActivity.this);
        firstName = getIntent().getStringExtra("firstName");
        lastName = getIntent().getStringExtra("lastName");
        email = getIntent().getStringExtra("email");
        phoneNumber = getIntent().getStringExtra("phoneNumber");
        firstNameEdt.setText(firstName);
        lastNameEdt.setText(lastName);
        emailEdt.setText(email);
        phoneNumberEdt.setText(phoneNumber);
        updateContactBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHandler.updateContact(firstName, firstNameEdt.getText().toString(), lastNameEdt.getText().toString(), emailEdt.getText().toString(), phoneNumberEdt.getText().toString());
                Toast.makeText(UpdateContactActivity.this, "Contact Updated..", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(UpdateContactActivity.this, MainActivity.class);
                startActivity(i);
            }
        });

        deleteContactBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHandler.deleteContact(firstName);
                Toast.makeText(UpdateContactActivity.this, "Deleted the contact", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(UpdateContactActivity.this, MainActivity.class);
                startActivity(i);
            }
        });
    }
}