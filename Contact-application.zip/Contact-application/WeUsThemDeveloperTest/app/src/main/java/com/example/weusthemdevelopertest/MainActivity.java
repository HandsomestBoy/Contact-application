package com.example.weusthemdevelopertest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import android.widget.EditText;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private ArrayList<ContactModal> contactModalArrayList;
    private DBHandler dbHandler;
    private ContactRVAdapter contactRVAdapter;
    private RecyclerView contactsRV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Contacts");
        contactModalArrayList = new ArrayList<>();
        dbHandler = new DBHandler(MainActivity.this);

        contactModalArrayList = dbHandler.readContacts();

        contactRVAdapter = new ContactRVAdapter(contactModalArrayList, MainActivity.this);
        contactsRV = findViewById(R.id.idRVContacts);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(MainActivity.this, RecyclerView.VERTICAL, false);
        contactsRV.setLayoutManager(linearLayoutManager);

        contactsRV.setAdapter(contactRVAdapter);
    }

    public void editOrAddContact(View v){
        Intent i = new Intent(this, EditContact.class);
        startActivity(i);
    }
}
