package com.example.weusthemdevelopertest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

public class EditContact extends AppCompatActivity {
    private EditText firstNameEdt, lastNameEdt, emailEdt, phoneNumberEdt;
    private Button saveBtn;
    private DBHandler dbHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_contact);
        firstNameEdt = findViewById(R.id.FirstName);
        lastNameEdt = findViewById(R.id.LastName);
        emailEdt = findViewById(R.id.Email);
        phoneNumberEdt = findViewById(R.id.PhoneNumber);
        saveBtn = findViewById(R.id.save);
        dbHandler = new DBHandler(EditContact.this);
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String firstName = firstNameEdt.getText().toString();
                String lastName = lastNameEdt.getText().toString();
                String email = emailEdt.getText().toString();
                String phoneNumber = phoneNumberEdt.getText().toString();
                if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || phoneNumber.isEmpty()) {
                    Toast.makeText(EditContact.this, "Please enter all the data.", Toast.LENGTH_SHORT).show();
                    return;
                }

                for (int i = 0 ;  i < email.length(); i++) {
                    if (email.indexOf("@") < 1 ) {
                        if (email.indexOf(".") < email.indexOf("@")+2)
                            if ((email.indexOf("@")+email.indexOf(".") - email.length()) < 1 )
                                Toast.makeText(EditContact.this, "Please enter email correctly.", Toast.LENGTH_SHORT).show();
                                return;
                    }
                }

                dbHandler.addNewContact(firstName, lastName, email, phoneNumber);
                Toast.makeText(EditContact.this, "Contact has been added.", Toast.LENGTH_SHORT).show();
                firstNameEdt.setText("");
                lastNameEdt.setText("");
                emailEdt.setText("");
                phoneNumberEdt.setText("");
            }
        });
    }
}