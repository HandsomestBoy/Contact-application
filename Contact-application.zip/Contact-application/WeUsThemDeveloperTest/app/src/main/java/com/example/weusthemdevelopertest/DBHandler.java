package com.example.weusthemdevelopertest;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {

    private static final String DB_NAME = "Contactdb";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "contacts";
    private static final String ID_COL = "id";
    private static final String FIRSTNAME_COL = "firstName";
    private static final String LASTNAME_COL = "lastName";
    private static final String EMAIL_COL = "email";
    private static final String PHONENUMBER_COL = "phoneNumber";

    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + FIRSTNAME_COL + " TEXT,"
                + LASTNAME_COL + " TEXT,"
                + EMAIL_COL + " TEXT,"
                + PHONENUMBER_COL + " TEXT)";

        db.execSQL(query);
    }

    public void addNewContact(String firstName, String lastName, String email, String phoneNumber) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(FIRSTNAME_COL, firstName);
        values.put(LASTNAME_COL, lastName);
        values.put(EMAIL_COL, email);
        values.put(PHONENUMBER_COL, phoneNumber);

        db.insert(TABLE_NAME, null, values);

        db.close();
    }

    public ArrayList<ContactModal> readContacts() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursorContacts = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        ArrayList<ContactModal> contactModalArrayList = new ArrayList<>();
        if (cursorContacts.moveToFirst()) {
            do {
                contactModalArrayList.add(new ContactModal(cursorContacts.getString(1),
                        cursorContacts.getString(2),
                        cursorContacts.getString(3),
                        cursorContacts.getString(4)));
            } while (cursorContacts.moveToNext());
        }
        cursorContacts.close();
        return contactModalArrayList;
    }

    public void updateContact(String originalFirstName, String firstName, String lastName,
                             String email, String phoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(FIRSTNAME_COL, firstName);
        values.put(LASTNAME_COL, lastName);
        values.put(EMAIL_COL, email);
        values.put(PHONENUMBER_COL, phoneNumber);
        db.update(TABLE_NAME, values, "firstname=?", new String[]{originalFirstName});
        db.close();
    }

    public void deleteContact(String firstName) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, "firstname=?", new String[]{firstName});
        db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}