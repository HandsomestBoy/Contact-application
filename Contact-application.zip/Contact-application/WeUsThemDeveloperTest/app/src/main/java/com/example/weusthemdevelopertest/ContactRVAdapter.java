package com.example.weusthemdevelopertest;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ContactRVAdapter extends RecyclerView.Adapter<ContactRVAdapter.ViewHolder> {
    private ArrayList<ContactModal> contactModalArrayList;
    private Context context;

    public ContactRVAdapter(ArrayList<ContactModal> contactModalArrayList, Context context) {
        this.contactModalArrayList = contactModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_rv_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ContactModal modal = contactModalArrayList.get(position);
        holder.firstNameTV.setText(modal.getFirstName());
        holder.lastNameTV.setText(modal.getLastName());
        holder.emailTV.setText(modal.getEmail());
        holder.phoneNumberTV.setText(modal.getPhoneNumber());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, UpdateContactActivity.class);
                i.putExtra("firstName", modal.getFirstName());
                i.putExtra("lastName", modal.getLastName());
                i.putExtra("email", modal.getEmail());
                i.putExtra("phoneNumber", modal.getPhoneNumber());
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        // returning the size of our array list
        return contactModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        // creating variables for our text views.
        private TextView firstNameTV, lastNameTV, emailTV, phoneNumberTV;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing our text views
            firstNameTV = itemView.findViewById(R.id.idTVFirstName);
            lastNameTV = itemView.findViewById(R.id.idTVLastName);
            emailTV = itemView.findViewById(R.id.idTVEmail);
            phoneNumberTV = itemView.findViewById(R.id.idTVPhoneNumber);
        }
    }
}
