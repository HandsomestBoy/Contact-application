Make sure you have Android Studio downloaded.
After unzip the folder "WeUsThemDeveloperTest",
Open Android Studio, click on "File>Open" and choose this folder.
On the toolbar by the top right corner, you can find a dropdown bar besides "app dropdown bar", 
expand the dropdown bar and click on "device manager" in Virtual tab click on "Create device"
Choose any device you want and hit next.
Download any version of the system build.
After downloaded the system click on "next" and "finish", choose the chosen device from the dropdown bar and hit the start button besides the dropdown bar.
Wait a while till the device get ready and opened the application itself, you can start testing out my application.
